#include "Component.h"

Component::Component()
{
}

Component::~Component()
{
}