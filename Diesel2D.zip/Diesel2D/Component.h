#pragma once

class Component
{
public:
	Component();
	~Component();
};
