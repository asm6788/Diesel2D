#pragma once
#include "SceneManger.h"
#include "Diesel2D.h"
#include <any>

using namespace std;
class Scene1
	: Scene
{
public:
	Scene1();
	~Scene1();
};
